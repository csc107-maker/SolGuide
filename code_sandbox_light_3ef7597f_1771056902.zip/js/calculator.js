// ==================== 
// Solar Calculator Logic
// ==================== 

// Constants (2026 prices)
const PRICES = {
    smpPrice: 90,           // SMP price (won/kWh)
    recPrice: 70000,        // REC price (won/REC)
    recWeightSmall: 1.5,    // REC weight for <100kW
    recWeightLarge: 1.2,    // REC weight for >=100kW
    systemEfficiency: 0.85, // System efficiency
    maintenanceCost: 0.02,  // Annual maintenance (2% of initial cost)
    degradation: 0.005      // Annual degradation rate (0.5%)
};

// Get form elements
const calculatorForm = document.getElementById('solarCalculator');
const resultsContent = document.getElementById('resultsContent');
const resultsPlaceholder = document.querySelector('.results-placeholder');
const financingInputs = document.querySelectorAll('input[name="financing"]');
const financingRateGroup = document.getElementById('financingRateGroup');

// Toggle financing rate input
financingInputs.forEach(input => {
    input.addEventListener('change', (e) => {
        if (e.target.value === 'yes') {
            financingRateGroup.style.display = 'block';
        } else {
            financingRateGroup.style.display = 'none';
        }
    });
});

// Form submission
calculatorForm.addEventListener('submit', (e) => {
    e.preventDefault();
    calculateSolarRevenue();
});

function calculateSolarRevenue() {
    // Get input values
    const capacity = parseFloat(document.getElementById('capacity').value);
    const sunHours = parseFloat(document.getElementById('region').value);
    const installType = document.getElementById('installType').value;
    const installCost = parseFloat(document.getElementById('installCost').value) * 10000; // Convert to won
    const financing = document.querySelector('input[name="financing"]:checked').value;
    const financingRate = financing === 'yes' ? parseFloat(document.getElementById('financingRate').value) / 100 : 0;

    // Calculate annual generation (kWh)
    const annualGeneration = capacity * sunHours * 365 * PRICES.systemEfficiency;
    
    // Determine REC weight
    const recWeight = capacity < 100 ? PRICES.recWeightSmall : PRICES.recWeightLarge;
    
    // Calculate annual revenue
    const smpRevenue = annualGeneration * PRICES.smpPrice;
    const recRevenue = (annualGeneration / 1000) * recWeight * PRICES.recPrice;
    const annualRevenue = smpRevenue + recRevenue;
    const monthlyRevenue = annualRevenue / 12;
    
    // Calculate maintenance cost
    const annualMaintenance = installCost * PRICES.maintenanceCost;
    const netAnnualRevenue = annualRevenue - annualMaintenance;
    
    // Calculate financing
    const financingAmount = installCost * financingRate;
    const actualInvestment = installCost - financingAmount;
    
    // Calculate ROI
    const breakEvenYears = actualInvestment / netAnnualRevenue;
    const breakEvenMonths = Math.ceil(breakEvenYears * 12);
    
    // Calculate 20-year revenue
    let totalRevenue20 = 0;
    for (let year = 1; year <= 20; year++) {
        const yearlyDegradation = Math.pow((1 - PRICES.degradation), year - 1);
        totalRevenue20 += annualRevenue * yearlyDegradation;
    }
    
    const totalMaintenance20 = annualMaintenance * 20;
    const netProfit20 = totalRevenue20 - totalMaintenance20 - actualInvestment;
    
    // Calculate average ROI
    const averageROI = ((netProfit20 / actualInvestment) / 20) * 100;
    
    // Display results
    displayResults({
        totalCost: installCost,
        financingAmount: financingAmount,
        actualInvestment: actualInvestment,
        annualGeneration: annualGeneration,
        monthlyRevenue: monthlyRevenue,
        annualRevenue: annualRevenue,
        totalRevenue20: totalRevenue20,
        breakEvenMonths: breakEvenMonths,
        breakEvenYears: breakEvenYears,
        netProfit20: netProfit20,
        averageROI: averageROI
    });
    
    // Create chart
    createRevenueChart(actualInvestment, netAnnualRevenue);
}

function displayResults(data) {
    // Hide placeholder, show results
    resultsPlaceholder.style.display = 'none';
    resultsContent.style.display = 'block';
    
    // Format and display values
    document.getElementById('totalCost').textContent = formatKRW(data.totalCost);
    document.getElementById('financingAmount').textContent = formatKRW(data.financingAmount);
    document.getElementById('actualInvestment').textContent = formatKRW(data.actualInvestment);
    document.getElementById('annualGeneration').textContent = formatNumber(Math.round(data.annualGeneration)) + ' kWh';
    document.getElementById('monthlyRevenue').textContent = formatKRW(Math.round(data.monthlyRevenue));
    document.getElementById('annualRevenue').textContent = formatKRW(Math.round(data.annualRevenue));
    document.getElementById('totalRevenue20').textContent = formatKRW(Math.round(data.totalRevenue20));
    document.getElementById('breakEvenPeriod').textContent = `${Math.floor(data.breakEvenYears)}년 ${data.breakEvenMonths % 12}개월`;
    document.getElementById('netProfit20').textContent = formatKRW(Math.round(data.netProfit20));
    document.getElementById('averageROI').textContent = data.averageROI.toFixed(2) + '%';
    
    // Scroll to results
    resultsContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function createRevenueChart(investment, annualRevenue) {
    const ctx = document.getElementById('revenueChart');
    
    // Destroy existing chart if it exists
    if (window.revenueChartInstance) {
        window.revenueChartInstance.destroy();
    }
    
    // Generate data for 20 years
    const years = [];
    const cumulativeRevenue = [];
    let cumulative = -investment;
    
    for (let i = 1; i <= 20; i++) {
        years.push(i + '년');
        const yearlyDegradation = Math.pow((1 - PRICES.degradation), i - 1);
        cumulative += annualRevenue * yearlyDegradation;
        cumulativeRevenue.push(Math.round(cumulative));
    }
    
    // Create chart
    window.revenueChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: years,
            datasets: [{
                label: '누적 수익 (원)',
                data: cumulativeRevenue,
                borderColor: '#1E88E5',
                backgroundColor: 'rgba(30, 136, 229, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '누적 수익: ' + formatKRW(context.parsed.y);
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return (value / 100000000).toFixed(0) + '억';
                        }
                    }
                }
            }
        }
    });
}

// Utility functions
function formatKRW(number) {
    if (number >= 100000000) {
        return (number / 100000000).toFixed(1) + '억 원';
    } else if (number >= 10000) {
        return (number / 10000).toFixed(0) + '만 원';
    } else {
        return Math.round(number).toLocaleString('ko-KR') + '원';
    }
}

function formatNumber(number) {
    return number.toLocaleString('ko-KR');
}

// Auto-calculate install cost based on capacity
document.getElementById('capacity').addEventListener('input', (e) => {
    const capacity = parseFloat(e.target.value);
    if (capacity && capacity > 0) {
        // Average cost: 1.2M won per kW
        const estimatedCost = Math.round(capacity * 120);
        document.getElementById('installCost').value = estimatedCost;
    }
});

// Update financing rate label based on company type
document.getElementById('financingRate').addEventListener('input', (e) => {
    const rate = e.target.value;
    const small = e.target.parentElement.querySelector('small');
    if (rate >= 75) {
        small.textContent = '중소기업: 최대 80%';
        small.style.color = '#43A047';
    } else if (rate >= 60) {
        small.textContent = '중견기업: 최대 65%';
        small.style.color = '#1E88E5';
    } else {
        small.textContent = '중소기업: 최대 80%, 중견기업: 최대 65%';
        small.style.color = '#757575';
    }
});
